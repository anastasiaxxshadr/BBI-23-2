﻿using lab_9_3.Serialization;

class Team
{
    public string team { get;  set; }
    public int scored { get;  set; }
    public int missed { get;  set; }
    public int points { get;  set; }
    public string gender { get;  set; }
    public virtual void calculatepoints()
    {
        points = scored > missed ? 3 : scored == missed ? 1 : 0;
    }
    public virtual void info(int place)
    {
        Console.WriteLine($"{place}\t{team}\t{gender}\t{points}");
    }
}
class WomenTeam : Team
{
    public WomenTeam(string name, int Scored, int Missed)
    {
        team = name;
        scored = Scored;
        missed = Missed;
        gender = "Ж";
    }
    public override void calculatepoints()
    {
        base.calculatepoints();
        points += 1;
    }
}
class MenTeam : Team
{
    public MenTeam(string name, int Scored, int Missed)
    {
        team = name;
        scored = Scored;
        missed = Missed;
        gender = "M";
    }
    public override void calculatepoints()
    {
        base.calculatepoints();
        points += 1;
    }
}
class Program3
{
    static void Main(string[] args)
    {
        MenTeam[] menTeams = {
            new MenTeam("CSKA", 1, 1),
            new MenTeam("Dinamo", 0, 3)
        };

        WomenTeam[] womenTeams = {
            new WomenTeam("Dinamo", 2, 1),
            new WomenTeam("Spartak", 3, 0)
        };

        Team[] allTeams = menTeams.Cast<Team>().Concat(womenTeams.Cast<Team>()).ToArray();

        foreach (var team in allTeams)
        {
            team.calculatepoints();
        }
        sort(allTeams);

        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Shadrina"); ;
        string folder = "Lab9_3";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string file_names = "9.3.json";


        SerializeManager serializers = new JsonMySerializer();

        serializers.Write(allTeams, Path.Combine(path, file_names));

        allTeams = serializers.Read <Team[]>(Path.Combine(path, file_names));
        res(allTeams);
    }

    private static void sort(Team[] teams)
    {
        for (int i = 0; i < 4 - 1; i++)
        {
            for (int j = 0; j < 4 - i - 1; j++)
            {
                if (teams[j].points < teams[j + 1].points || (teams[j].points == teams[j + 1].points && (teams[j].scored - teams[j].missed) < (teams[j + 1].scored - teams[j + 1].missed)))
                {
                    Team t = teams[j];
                    teams[j] = teams[j + 1];
                    teams[j + 1] = t;
                }
            }
        }
    }
    private static void res(Team[] teams)
    {
        Console.WriteLine("Результирующая таблица:");
        Console.WriteLine("Место\tКоманда\tПол\tОчки");
        for (int i = 0; i < teams.Length; i++)
        {
            teams[i].info(i + 1);
        }
    }
}