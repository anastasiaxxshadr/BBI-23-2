﻿using lab_9_1.Serialization;

public abstract class Answer
{
    public string Title { get; set; }
    public int Count { get;  set; }
    public double Percentage { get;  set; }

    public void SetPercentage(double percentage)
    {
        Percentage = percentage;
    }

    public Answer(string title, int count)
    {

        Title = title;
        Count = count;
    }
    public Answer() { }
    public abstract void Display();
}
public class PersonOfYear : Answer
{
    public PersonOfYear(string title, int count) : base(title, count) { }
    public PersonOfYear() { }
    public override void Display()
    {
        Console.WriteLine($"Имя: {Title,-7} количество голосов: {Count,-5} процент от общего количества: {Percentage,-5:F2}%");
    }
}

public class DiscoveryOfYear : Answer
{
    public DiscoveryOfYear(string title, int count) : base(title, count) { }
    public DiscoveryOfYear() { }
    public override void Display()
    {
        Console.WriteLine($"Открытие года: {Title,-14} количество голосов: {Count,-5} процент от общего количества: {Percentage,-5:F2}%");
    }
}
class Program
{
    static void Main()
    {
        PersonOfYear[] personAnswers = new PersonOfYear[7]
        {
            new PersonOfYear("Bob", 10),
            new PersonOfYear("Mark", 20),
            new PersonOfYear("Dylan", 14),
            new PersonOfYear("Kate", 17),
            new PersonOfYear("Mary", 11),
            new PersonOfYear("John", 5),
            new PersonOfYear("Pete", 15)
        };

        DiscoveryOfYear[] discoveryAnswers = new DiscoveryOfYear[6]
        {
            new DiscoveryOfYear("Открытие 1", 37),
            new DiscoveryOfYear("Открытие 2", 21),
            new DiscoveryOfYear("Открытие 3", 25),
            new DiscoveryOfYear("Открытие 4", 15),
            new DiscoveryOfYear("Открытие 5", 8),
            new DiscoveryOfYear("Открытие 6", 10)
        };

        int SumAns = 0;
        foreach (var answer in personAnswers)
        {
            SumAns += answer.Count;
        }

        for (int i = 0; i < personAnswers.Length; i++)
        {
            for (int j = i; j < personAnswers.Length; j++)
            {
                if (personAnswers[i].Count < personAnswers[j].Count)
                {
                    (personAnswers[i], personAnswers[j]) = (personAnswers[j], personAnswers[i]);
                }
            }
        }

        int SumDiscovery = 0;
        foreach (var answer in discoveryAnswers)
        {
            SumDiscovery += answer.Count;
        }

        for (int i = 0; i < discoveryAnswers.Length; i++)
        {
            for (int j = i; j < discoveryAnswers.Length; j++)
            {
                if (discoveryAnswers[i].Count < discoveryAnswers[j].Count)
                {
                    (discoveryAnswers[i], discoveryAnswers[j]) = (discoveryAnswers[j], discoveryAnswers[i]);
                }
            }
        }
        for (int i = 0; i < 5; i++)
        {
            personAnswers[i].SetPercentage((double)personAnswers[i].Count / SumAns * 100);
        }
        for (int i = 0; i < 5; i++)
        {
            discoveryAnswers[i].SetPercentage((double)discoveryAnswers[i].Count / SumDiscovery * 100);
        }

        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Shadrina", "Lab9_1");
        if (!Directory.Exists(path))
            Directory.CreateDirectory(path);

        JsonMySerializer serializers = new JsonMySerializer();
        string jsonFile = Path.Combine(path, "lab9_1_person.json");
        serializers.Write<PersonOfYear[]>(personAnswers, jsonFile);
        PersonOfYear[] personAnswers2 = serializers.Read<PersonOfYear[]>(jsonFile);

        string jsonFile2 = Path.Combine(path, "lab9_1_discovery.json");
        serializers.Write<DiscoveryOfYear[]>(discoveryAnswers, jsonFile2);
        DiscoveryOfYear[] discoveryAnswers2 = serializers.Read<DiscoveryOfYear[]>(jsonFile2);

        Console.WriteLine("Топ персон года:");
        for (int i = 0; i < 5; i++)
        { 
            personAnswers2[i].Display();
        }

        Console.WriteLine("\nТоп открытий года:");
        for (int i = 0; i < 5; i++)
        {
            discoveryAnswers2[i].Display();
        }
        
    }

}
